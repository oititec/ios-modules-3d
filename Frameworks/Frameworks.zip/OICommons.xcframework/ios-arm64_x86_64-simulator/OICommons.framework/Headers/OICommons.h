//
//  OICommons.h
//  OICommons
//
//  Created by Vitor Souza on 30/11/22.
//

#import <Foundation/Foundation.h>

//! Project version number for OICommons.
FOUNDATION_EXPORT double OICommonsVersionNumber;

//! Project version string for OICommons.
FOUNDATION_EXPORT const unsigned char OICommonsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OICommons/PublicHeader.h>


