//
//  OILiveness3D.h
//  OILiveness3D
//
//  Created by Vitor Souza on 08/12/22.
//

#import <Foundation/Foundation.h>

//! Project version number for OILiveness3D.
FOUNDATION_EXPORT double OILiveness3DVersionNumber;

//! Project version string for OILiveness3D.
FOUNDATION_EXPORT const unsigned char OILiveness3DVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OILiveness3D/PublicHeader.h>


